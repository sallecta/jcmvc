<?php 
defined('_JEXEC') or die;
use Joomla\CMS\Uri\Uri;
?>
<?php
$jcmvc_url_site = Uri::root().'index.php?option=com_jcmvc';
?>
<hr />
<h1>admin/jcmvc.php</h1>
<p>Important! Around version 3.8 the Joomla developers started changing the naming of Joomla classes and where they were stored in the directory structure. Many of the tutorial steps and videos refer to the old naming convention. To find the equivalent new class and where it's stored, look in your libraries/classmap.php file.</p>
<p>Link to the site part of the component: <a href="<?php echo $jcmvc_url_site ;?>" target="_blank">site/jcmvc.php</a></p>
<hr />

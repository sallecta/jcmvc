<?php $jcmvc_url_admin = JURI::root().'administrator/index.php?option=com_jcmvc'; ?>
<h1>admin/jcmvc.php</h1>
<p>Link to the admin part of the component: <a href="<?php echo $jcmvc_url_admin ;?>" target="_blank">site/jcmvc.php</a></p>

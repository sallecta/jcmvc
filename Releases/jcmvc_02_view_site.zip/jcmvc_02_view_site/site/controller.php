<?php
defined('_JEXEC') or die('Restricted access');
class JcmvcController extends JControllerLegacy
{
}

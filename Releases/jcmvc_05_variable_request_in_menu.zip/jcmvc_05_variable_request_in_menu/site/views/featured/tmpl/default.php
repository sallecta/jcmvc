<?php
defined('_JEXEC') or die();
// $this refers to the current view class
?>
<h1><?php echo $this->msg; ?></h1>
